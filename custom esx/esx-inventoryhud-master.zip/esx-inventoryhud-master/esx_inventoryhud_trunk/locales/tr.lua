Locales["tr"] = {
  ["trunk_closed"] = "Bagaj kapatıldı.",
  ["no_veh_nearby"] = "Yakında araç yok.",
  ["trunk_in_use"] = "Başka birisi bagajı kullanıyor.",
  ["trunk_full"] = "Bagaj dolu.",
  ["invalid_quantity"] = "Geçersiz miktar.",
  ["cant_carry_more"] = "Daha fazlasını taşıyamazsın.",
  ["nacho_veh"] = "Bu araç senin değil.",
  ["invalid_amount"] = "Geçersiz miktar.",
  ["insufficient_space"] = "Yetersiz alan.",
  ["trunk_info"] = "<h3>Bagaj</h3><br><strong>Plaka:</strong> %s<br><strong>Kapasite:</strong> %s / %s",
  ["player_inv_no_space"] = "Bu eşya için envanterinde yeterince yer yok!"
}
