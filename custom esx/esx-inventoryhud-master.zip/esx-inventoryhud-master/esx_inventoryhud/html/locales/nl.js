var invLocale = new Object();
invLocale.dropItem = "LAten vallen";
invLocale.useItem = "Gebruiken";
invLocale.giveItem = "Geven";
invLocale.secondInventoryNotAvailable = "Secundaire inventaris is niet beschikbaar.";