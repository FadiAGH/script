var invLocale = new Object();
invLocale.dropItem = "Jeter";
invLocale.useItem = "Utiliser";
invLocale.giveItem = "Donner";
invLocale.secondInventoryNotAvailable = "L'inventaire secondaire n'est pas disponible.";