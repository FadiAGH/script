# esx_jb_trailer

trailer script from Jager Bom

place trailersmall folder into your ressources and start both ressources.

```
start trailersmall
start esx_jb_trailer
```
thanks to @XxFri3ndlyxX for updated config file and @JHodgson1 for adding the locales !
