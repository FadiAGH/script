# esx_thelostmc

INSTALLATION:

Download the file.

Add all the files to [esx] folder in the resources folder.

Add the esx_thelostmc.sql file to the database.

Add this to server.cfg => start esx_thelostmc

Clean the cache and start the server.
