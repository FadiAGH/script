INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES ('fish', 'Fish', 100, 0, 1);
INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES ('fishbait', 'Fish Bait', 30, 0, 1);
INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES ('fishingrod', 'Fishing Rod', 2, 0, 1);
INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES ('shark', 'Shark', -1, 0, 1);
INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES ('turtle', 'Sea Turtle', 3, 0, 1);
INSERT INTO `items` (`name`, `label`, `limit`, `rare`, `can_remove`) VALUES ('turtlebait', 'Turtle Bait', 10, 0, 1);