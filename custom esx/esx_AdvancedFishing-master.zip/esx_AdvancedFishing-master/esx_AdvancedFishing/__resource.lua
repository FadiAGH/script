

client_scripts {
  'config.lua',
  'client.lua'
}
server_scripts { 
	'server.lua',  
	'config.lua'
}
