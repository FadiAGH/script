Locales ['en'] = {
	['used_kit']					= 'you used ~y~x1 ~b~Repairkit',
	['must_be_outside']				= 'you must be outside of the vehicle!',
	['no_vehicle_nearby']			= 'there is no ~r~vehicle ~w~nearby',
	['finished_repair']				= '~g~you repaired the vehicle!',
	['abort_hint']					= 'press ~INPUT_VEH_DUCK~ to cancel',
	['aborted_repair']				= 'you ~r~aborted ~w~the repairs',
}