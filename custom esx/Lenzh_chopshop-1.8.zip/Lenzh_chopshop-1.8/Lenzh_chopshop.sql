USE `essentialmode`;


INSERT INTO `items` (`name`, `label`, `limit`) VALUES
  ('battery', 'Car Battery', 2),
  ('lowradio', 'Stock Radio', 5),
  ('stockrim', 'Stock Rim', 4),
  ('airbag', 'Airbag', 7),
  ('highradio', 'Aftermarket Radio', 5),
  ('highrim', 'Nice Rim', 4)

;
