Script made by Kuzkay

Items db:
-Acetone
-Methlab
-Lithium
-Meth

(You can use sql.sql file)


=================/

This is an very old script I've made probably back in October of 2018 and haven't published it since
It's not as optimized nor does it use OOP but still works fine and doesn't cause any fps drops what so ever.
Good luck using it, I can answer simple questions about it but won't deliver constant support.

Feel free to upgrade this resource and change stuff up, if you want to publish it make sure you-
always link to the original resource and give me credit

Twitter: @KuzkayDev
Discord: Kuzkay#9999
Youtube: Kuzkay