Config = {}

Config.PickupBlip = {x = -1833.4  , y = 2176.7 ,z = 107.2}
Config.Processing = {x = 2434.2  , y = 4968.6, z =41.3}


