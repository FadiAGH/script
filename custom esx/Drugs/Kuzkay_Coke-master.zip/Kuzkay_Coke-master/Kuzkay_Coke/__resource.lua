print("Kuzkay_Coke has successfully started. Enjoy!")

client_scripts {
  'config.lua',
  'client.lua'
}
server_script "server.lua"
