INSERT INTO `items` (name, label, `limit`) VALUES
	('bitcoinitem', 'Bitcoin', 50)
;