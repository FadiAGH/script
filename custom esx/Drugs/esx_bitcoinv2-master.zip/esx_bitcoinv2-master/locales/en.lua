Locales['en'] = {
	['press_take_bitcoin'] = 'Press ~INPUT_CONTEXT~ to catch Bitcoin',
	['press_sell_bitcoin'] = 'Press ~INPUT_CONTEXT~ to sell the BitCoin',
	['inventory_full'] = 'You can not get more Bicoin because your ~r~Iventory~s~',
	['take_bitcoin'] = '~y~A Minerar Bitcoin~s~...',
	['you_dont_have_bitcoin2'] = 'You Do not Have More ~r~Bicoin~s~',
	['you_dont_have_bitcoin'] = 'You Do not Have More ~r~Bitcoin~s~',
	['bitcoin_sell'] = 'Sell ~y~x1~s~ ~y~Bitcoin~s~',
	['bitcoin_selltext'] = '~g~For sale Bitcoin~s~...',
}