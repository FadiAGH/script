# 💰 esx_BitcoinV2 💰

You gotta pick up and sell bitcoin

Items
-Bitcoin

# Installation
1. Install Script
3. Copy the project to your esx resource folder.
4. Do not forget to import the database.sql file into your database.
5. Add "start esx_bitcoinv2" to your file `server.cfg`

# Download
EN : https://github.com/jordann124/esx_bitcoinEN

_es_extended_ - https://mega.nz/#!It5CDSrD!w8S9GyxsC_0mz68TqDUXSgA-P5FmQAq0-5Oy2HzcvAI

# 🍀 Good Luck  🍀
