# esx_pickweed
This script uses a prop cache instead of coordinates to enable "pickable" marijuana around San Andreas. Requires ESX framework and "weed" item in the database.

I am not maintaining this script or providing direct support for it, you can reply in the forum thread or create a issue/PR and I will address at my next best conveinence.


# Operation:
1. Create "weed" item in your database items table.
2. Add "esx_pickweed" to your server.cfg
3. Head to any location with weed props and pick your plants!
4. For additional use of the script we reccomend using: https://forum.fivem.net/t/esx-sell-drugs-to-npcs-weed-only/89355



# esx_pickweed

## Requirements

  * [esx_extended]https://github.com/ESX-Org/es_extended
  
## Download & Installation

### Using Git
```
cd resources
git clone https://github.com/TayUE4/esx_pickweed/

```

### Manually
- Download https://github.com/TayUE4/esx_pickweed/
- Put it in the `[esx]` directory


# Legal
### License
esx_pickweed

Copyright (C) 2015-2019 Taylor Mckenzie

This program Is free software: you can redistribute it And/Or modify it under the terms Of the GNU General Public License As published by the Free Software Foundation, either version 3 Of the License, Or (at your option) any later version.

This program Is distributed In the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty Of MERCHANTABILITY Or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License For more details.

You should have received a copy Of the GNU General Public License along with this program. If Not, see http://www.gnu.org/licenses/.


![image](https://i.imgur.com/rsxAilD.jpg)
