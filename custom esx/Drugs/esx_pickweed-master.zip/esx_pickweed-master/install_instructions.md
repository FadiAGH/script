#Install Instructions:
1. Create "weed" item in your database items table.
2. Add "esx_pickweed" to your server.cfg
3. Head to any location with weed props and pick your plants!
4. For additional use of the script we reccomend using: https://forum.fivem.net/t/esx-sell-drugs-to-npcs-weed-only/89355