**ESX_MoneyWash**

A money washing script for FiveM. 

FiveM forum post: https://forum.fivem.net/t/esx-moneywash/827640

**Details:**

This is a script using the ESX framework. I am currently using this on my server without any errors. I am using this along side esx_society. This script is very easy to use. It allows users to wash their dirty money at set locations though out the map. currently it is only one location but more can easily be added in the config. The original location is using a part of the map that you need to set teleport up to.

I was looking for a money wash script and couldn't find exactly what I was looking for. There are a couple that allow you to either wash all your money or just do it in increments at a time. This script will allow you to choose how much you want to wash. It also includes a "tax" to not give a 1:1 dirty to clean ratio. The default tax rate can be changed in the config file. It currently gives 65% dirty to clean. 

This is my first release on FiveM and I am still learning LUA. Will try my best to fix any bugs that may arise but as stated before it is currently working on my server and throwing no errors. I also havent noticed any high unusual MS from the script. Let me know if you do experience these issues and I will work on optimizing it.

**Features:**

1. Washes dirty money instantly
2. Ability to set multiple washing locations
3. Ability to change tax rate to give more or less clean money
4. Easy to setup, add more locations, and change tax rate


**Installation:**

1. Add the following to your **server.cfg**
> start esx_moneywash
2. Insert esx_moneywash-master into your /resources/[ESX] folder
3. Rename esx_moneywash-master to esx_moneywash
4. Restart/Start your server


**Screenshots:**

![Image1](https://forum.fivem.net/uploads/default/original/4X/0/1/4/0140b63258e86613e5614a0c125cb2d685cffe31.jpeg)
![Image2](https://forum.fivem.net/uploads/default/original/4X/0/3/a/03a18bd911fa145b998ac4254c0cc97d470fcda0.jpeg)
![Image3](https://forum.fivem.net/uploads/default/original/4X/1/7/c/17c7798c9e9415d5a9657f2cf6bd41444a065f8f.jpeg)
![Image4](https://forum.fivem.net/uploads/default/original/4X/b/d/c/bdc9edf9d6e81bf540932c06abb896b078452e64.jpeg)
![Image5](https://forum.fivem.net/uploads/default/original/4X/f/f/0/ff00bb40a4965c635b3b90b5389ab2912fa3e0eb.jpeg)

**Download:**
<a href="https://github.com/iTzCrutchie/esx_moneywash/archive/master.zip">esx_moneywash</a>


**Credits**
https://github.com/ESX-Org/esx_society by ElPumpo

https://forum.fivem.net/t/release-simple-dirty-money-laundering-0-2-04-07-updated/25493 by Oskr
